const number1 = 10
const number2 = 5

const result = number1 + number2

console.log(result)