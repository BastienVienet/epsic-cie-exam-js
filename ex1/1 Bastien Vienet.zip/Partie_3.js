let nb = 1;
const nb2 = 2;

document.write("Valeur de nb: " + nb + "<br>" +
    "Valeur de nb++: " + nb++ + "<br>" +
    "Valeur de nb: " + nb + "<br>" +
    "Valeur de nb++: " + ++nb + "<br>" +
    "Valeur de --nb: " + --nb + "<br>" +
    "nb+=nb2, valeur de nb: " + (nb += nb2) + "<br>"
);
