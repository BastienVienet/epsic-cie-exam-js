const sentence1 = "Ceci est"
const sentence2 = "une chaine concaténé"

const result = sentence1 + " " + sentence2

console.log(result)